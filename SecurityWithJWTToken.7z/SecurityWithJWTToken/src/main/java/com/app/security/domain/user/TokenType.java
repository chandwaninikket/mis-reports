package com.app.security.domain.user;

public enum TokenType {
    BEARER
}
