package com.app.security.repository.users;

import com.app.security.domain.user.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {
    @Override
    Optional<Role> findById(Long aLong);

    @Override
    void delete(Role role);

    Optional<Role> findByRoleId(Long roleId);

    Optional<Role> findByName(String name);
}
